import React, { useState, useRef } from 'react';
import { FileText, Wand2, Download, Send, Copy, Check } from 'lucide-react';
import html2pdf from 'html2pdf.js';

interface ResumeData {
  fullName: string;
  email: string;
  phone: string;
  summary: string;
  experience: string;
  education: string;
  skills: string;
  projects: string;
}

function App() {
  const [resumeData, setResumeData] = useState<ResumeData>({
    fullName: '',
    email: '',
    phone: '',
    summary: '',
    experience: '',
    education: '',
    skills: '',
    projects: ''
  });

  const [aiSuggestions, setAiSuggestions] = useState<string>('');
  const [isSharing, setIsSharing] = useState(false);
  const [copied, setCopied] = useState(false);
  const resumeRef = useRef<HTMLDivElement>(null);

  const handleInputChange = (field: keyof ResumeData, value: string) => {
    setResumeData(prev => ({ ...prev, [field]: value }));
    
    if (field === 'experience' || field === 'summary' || field === 'projects') {
      setTimeout(() => {
        setAiSuggestions("Try using more action verbs and quantifiable achievements. For example: 'Increased team productivity by 25% through implementation of automated workflows.'");
      }, 1000);
    }
  };

  const handleDownloadPDF = () => {
    const element = resumeRef.current;
    if (!element) return;

    const opt = {
      margin: 1,
      filename: `${resumeData.fullName.toLowerCase().replace(/\s+/g, '_')}_resume.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };

    html2pdf().set(opt).from(element).save();
  };

  const handleShare = () => {
    setIsSharing(true);
  };

  const copyToClipboard = async () => {
    try {
      const resumeContent = resumeRef.current?.innerText;
      if (resumeContent) {
        await navigator.clipboard.writeText(resumeContent);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  // Helper function to split comma-separated text into an array
  const splitByComma = (text: string) => {
    return text.split(',').map(item => item.trim()).filter(item => item.length > 0);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="container mx-auto px-4 py-8">
        <header className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <FileText className="h-8 w-8 text-indigo-600" />
            <h1 className="text-4xl font-bold text-gray-800">ResumeAI</h1>
          </div>
          <p className="text-gray-600">Create a professional resume with AI-powered suggestions</p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Editor Section */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-2xl font-semibold mb-6 flex items-center gap-2">
              <Wand2 className="h-5 w-5 text-indigo-600" />
              Resume Editor
            </h2>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                <input
                  type="text"
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  value={resumeData.fullName}
                  onChange={(e) => handleInputChange('fullName', e.target.value)}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                  <input
                    type="email"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    value={resumeData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                  <input
                    type="tel"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    value={resumeData.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Professional Summary</label>
                <textarea
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 h-32"
                  value={resumeData.summary}
                  onChange={(e) => handleInputChange('summary', e.target.value)}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Work Experience</label>
                <textarea
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 h-48"
                  value={resumeData.experience}
                  onChange={(e) => handleInputChange('experience', e.target.value)}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Projects (comma-separated)</label>
                <textarea
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 h-48"
                  value={resumeData.projects}
                  onChange={(e) => handleInputChange('projects', e.target.value)}
                  placeholder="e.g., Built an e-commerce platform using React and Node.js, Developed a machine learning model for sentiment analysis"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Education (comma-separated)</label>
                <textarea
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 h-32"
                  value={resumeData.education}
                  onChange={(e) => handleInputChange('education', e.target.value)}
                  placeholder="e.g., Bachelor's in Computer Science - University A, Master's in Business - University B"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Skills (comma-separated)</label>
                <textarea
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 h-32"
                  value={resumeData.skills}
                  onChange={(e) => handleInputChange('skills', e.target.value)}
                  placeholder="e.g., JavaScript, React, Node.js, Project Management"
                />
              </div>
            </div>
          </div>

          {/* Preview & AI Suggestions Section */}
          <div className="space-y-8">
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-2xl font-semibold mb-6">Preview</h2>
              <div className="prose max-w-none" ref={resumeRef}>
                <h1 className="text-2xl font-bold">{resumeData.fullName || 'Your Name'}</h1>
                <div className="text-gray-600 mb-4">
                  {resumeData.email && <span className="mr-4">{resumeData.email}</span>}
                  {resumeData.phone && <span>{resumeData.phone}</span>}
                </div>
                
                {resumeData.summary && (
                  <div className="mb-6">
                    <h2 className="text-lg font-semibold mb-2">Professional Summary</h2>
                    <p>{resumeData.summary}</p>
                  </div>
                )}

                {resumeData.experience && (
                  <div className="mb-6">
                    <h2 className="text-lg font-semibold mb-2">Experience</h2>
                    <p>{resumeData.experience}</p>
                  </div>
                )}

                {resumeData.projects && (
                  <div className="mb-6">
                    <h2 className="text-lg font-semibold mb-2">Projects</h2>
                    <ul className="list-disc pl-5 space-y-1">
                      {splitByComma(resumeData.projects).map((project, index) => (
                        <li key={index}>{project}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {resumeData.education && (
                  <div className="mb-6">
                    <h2 className="text-lg font-semibold mb-2">Education</h2>
                    <ul className="list-disc pl-5 space-y-1">
                      {splitByComma(resumeData.education).map((item, index) => (
                        <li key={index}>{item}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {resumeData.skills && (
                  <div className="mb-6">
                    <h2 className="text-lg font-semibold mb-2">Skills</h2>
                    <ul className="list-disc pl-5 space-y-1">
                      {splitByComma(resumeData.skills).map((skill, index) => (
                        <li key={index}>{skill}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>

            {aiSuggestions && (
              <div className="bg-indigo-50 rounded-xl p-6 border border-indigo-100">
                <h2 className="text-lg font-semibold mb-2 flex items-center gap-2">
                  <Wand2 className="h-5 w-5 text-indigo-600" />
                  AI Suggestions
                </h2>
                <p className="text-gray-700">{aiSuggestions}</p>
              </div>
            )}

            <div className="flex gap-4">
              <button 
                onClick={handleDownloadPDF}
                className="flex-1 bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2"
              >
                <Download className="h-5 w-5" />
                Download PDF
              </button>
              <button 
                onClick={handleShare}
                className="flex-1 bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
              >
                <Send className="h-5 w-5" />
                Share Resume
              </button>
            </div>

            {/* Share Dialog */}
            {isSharing && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
                <div className="bg-white rounded-xl p-6 max-w-md w-full">
                  <h3 className="text-xl font-semibold mb-4">Share Resume</h3>
                  <p className="text-gray-600 mb-4">Copy your resume content to share:</p>
                  <button
                    onClick={copyToClipboard}
                    className="w-full bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2"
                  >
                    {copied ? (
                      <>
                        <Check className="h-5 w-5" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="h-5 w-5" />
                        Copy to Clipboard
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => setIsSharing(false)}
                    className="w-full mt-4 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    Close
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;